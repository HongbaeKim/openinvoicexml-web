# openinvoicexml

[![CI](https://github.com/HongbaeKim/openinvoicexml/actions/workflows/ci.yml/badge.svg)](https://github.com/HongbaeKim/openinvoicexml/actions/workflows/ci.yml)

An open-source TypeScript library for generating compliant German electronic invoices — XRechnung UBL XML, CII XML, and hybrid PDF/A-3 (including genuine Factur-X/ZUGFeRD, EN16931/XRechnung profiles).

From 2028 onward, all domestic B2B invoices in Germany must be issued as structured electronic invoices. This library handles the full pipeline: structured JSON input → validated XRechnung XML → hybrid PDF with embedded XML.

Funded by [Prototype Fund](https://www.prototypefund.de/projects/openinvoicexml) (June–November 2026).

## What it does

- Generates XRechnung 3.x compliant UBL 2.1 XML from a structured JSON invoice
- Validates output against KoSIT (the official German e-invoice validator)
- Exports hybrid PDF/A-3b: `toHybridPdf()` embeds the XRechnung UBL XML as an associated file
  (veraPDF-validated); `toFacturXPdf()` embeds CII via `embedFacturX()` for a genuine
  Factur-X/ZUGFeRD conformance claim (`EN16931`/`XRECHNUNG` profiles — see
  [docs/LIMITATIONS.md](docs/LIMITATIONS.md) for the MINIMUM/BASIC WL/BASIC gap), validated
  against KoSIT, veraPDF, and Mustang
- `generateInvoiceDocument(invoice, { format })` gives one call site across all four output
  formats — XRechnung UBL, XRechnung CII, Factur-X/ZUGFeRD EN16931, Factur-X/ZUGFeRD XRechnung —
  without callers needing to know which adapter or `profile` value each one maps to
- Covers major German VAT and legal scenarios: [§19][ustg-19] small business, [§13b][ustg-13b] reverse charge, intra-EU supply, credit notes, down payment invoices, and more

## Status

Phase 4 (Hybrid PDF/A-3 Export) done, tagged v0.4.0 — XRechnung UBL XML, CII XML, hybrid PDF/A-3
(UBL and genuine Factur-X/ZUGFeRD), and unified compliance diagnostics are all implemented and
validated against KoSIT, veraPDF, and Mustang across 54 fixtures (see
[docs/COMPLIANCE.md](docs/COMPLIANCE.md#validating-this-projects-output)). Phase 5
(stabilization & release prep) is in progress — CI now enforces test coverage thresholds, and v0.4.1 adds input validation and XML escaping to every `generate*()` function. See [docs/ROADMAP.md](docs/ROADMAP.md) for the full plan.

## Prerequisites

- Node.js 20+
- npm 10+

## Install

```bash
npm install
```

## Run tests

```bash
npm test
```

CI (`.github/workflows/ci.yml`) also runs `npm run lint` and `npm run typecheck` on every push
and PR to `main`.

## Project structure

```
/core         — internal invoice schema and normalization
/adapters     — output adapters (XRechnung XML, PDF/A-3)
/validators   — validation layer (schema, KoSIT, veraPDF)
  /rules      — individual business rule implementations
/fixtures     — example invoices and expected outputs
/docs         — architecture, roadmap, and API docs
```

## Docs

| Document                                                                                                      | Status |
| ------------------------------------------------------------------------------------------------------------- | ------ |
| `ARCHITECTURE.md` — Adapter pattern, module boundaries, data flow                                             | Done   |
| `DEVELOPMENT.md` — Local setup, available commands, TypeScript/dependency config, coding & commit conventions | Done   |
| `COMPLIANCE.md` — Index of compliance sources, rule → file → status map, KoSIT validation setup and usage     | Done   |
| `DATA-MODEL.md` — Internal invoice schema, full XRechnung BT mapping table                                    | Done   |
| `API.md` — API usage: `generateInvoiceDocument`, `generateInvoice`, `toXRechnung`, error codes                | Done   |
| `ROADMAP.md` — Phase goals, non-goals, open questions                                                         | Done   |
| `LIMITATIONS.md` — What is not supported and why                                                              | Done   |
| `SECURITY.md` — Security considerations and responsible disclosure                                            | Done   |

## Companion repo

The hosted website, beta/developer signup backend, and deploy tooling live in a separate repo,
[`openinvoicexml-web`](https://github.com/HongbaeKim/openinvoicexml-web), which consumes this
engine rather than the other way around.

## License

Apache-2.0

Optional external validators (KoSIT, Mustangproject, veraPDF) are independent projects under
their own licenses and are not bundled — see
[docs/COMPLIANCE.md](docs/COMPLIANCE.md#third-party-validation-tools).

---

<p>
  <img src="logo/en/BMFTR_en.png" alt="Logo of the German Federal Ministry of Research, Technology and Space" height="80">
  <img src="logo/en/P_en.png" alt="Prototype Fund logo" height="80">
</p>

[ustg-13b]: https://www.gesetze-im-internet.de/ustg_1980/__13b.html
[ustg-19]: https://www.gesetze-im-internet.de/ustg_1980/__19.html
