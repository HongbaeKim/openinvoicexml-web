# openinvoicexml

[![CI](https://github.com/HongbaeKim/openinvoicexml/actions/workflows/ci.yml/badge.svg)](https://github.com/HongbaeKim/openinvoicexml/actions/workflows/ci.yml)

An open-source TypeScript library for generating compliant German electronic invoices — XRechnung UBL XML, CII XML, and hybrid PDF/A-3 (including genuine Factur-X/ZUGFeRD, EN16931/XRechnung profiles).

From 2028 onward, all domestic B2B invoices in Germany must be issued as structured electronic invoices. This library handles the full pipeline: structured JSON input → validated XRechnung XML → hybrid PDF with embedded XML.

> Eine deutsche Fassung dieser Seite: [README.de.md](README.de.md). Translations are maintained by
> hand and may lag behind the English version.

Funded by [Prototype Fund](https://www.prototypefund.de/projects/openinvoicexml) (June–November 2026).

## What it does

- Generates XRechnung 3.x compliant UBL 2.1 XML from a structured JSON invoice
- Validates output against KoSIT (the official German e-invoice validator)
- Exports hybrid PDF/A-3b: `toHybridPdf()` embeds the XRechnung UBL XML as an associated file
  (veraPDF-validated); `toFacturXPdf()` embeds CII via `embedFacturX()` for a genuine
  Factur-X/ZUGFeRD conformance claim (`EN16931`/`XRECHNUNG` profiles — see
  [docs/LIMITATIONS.md](docs/LIMITATIONS.md) for the MINIMUM/BASIC WL/BASIC gap), validated
  against KoSIT, veraPDF, and Mustang
- `generateInvoiceDocument(invoice, { format })` gives one call site across all four output
  formats — XRechnung UBL, XRechnung CII, Factur-X/ZUGFeRD EN16931, Factur-X/ZUGFeRD XRechnung —
  without callers needing to know which adapter or `profile` value each one maps to
- Runs in the browser too: `openinvoicexml/browser` generates XRechnung XML and PDFs locally;
  external validators need Java and run only in Node.js
- Covers major German VAT and legal scenarios: [§19][ustg-19] small business, [§13b][ustg-13b] reverse charge, intra-EU supply, credit notes, down payment invoices, and more — see [docs/SUPPORTED_SCENARIOS.md](docs/SUPPORTED_SCENARIOS.md) for the full list

## Status

Feature-complete for the funded scope and in final stabilization before `v1.0.0`. XRechnung UBL
XML, CII XML, hybrid PDF/A-3 (UBL and genuine Factur-X/ZUGFeRD) and unified compliance diagnostics
are implemented and validated against KoSIT, veraPDF and Mustang, with 63 fixtures and 2,000+
automated tests (see [docs/COMPLIANCE.md](docs/COMPLIANCE.md#validating-this-projects-output)). CI
enforces coverage thresholds. Releases are listed in [CHANGELOG.md](CHANGELOG.md); the plan is in
[docs/ROADMAP.md](docs/ROADMAP.md).

## Prerequisites

- Basic development: Node.js 20+, npm 10+ and `git`
- External validator setup (KoSIT, veraPDF, Mustang): `make`, `bash`, `curl`, `unzip` and `tar`.
  Java does not need a separate installation: the setup scripts download a portable JRE if none is
  found.

## Install

```bash
npm install openinvoicexml
```

To work on the library itself, clone the repo and see [Run tests](#run-tests).

## Run tests

Fast path (enough for most changes):

```bash
npm install
npm test
```

Full path, with the real KoSIT, veraPDF and Mustang checks:

```bash
make kosit-setup && make verapdf-setup && make mustang-setup
npm run build
npm test
```

Without the validators, their tests are skipped, not failed, and the package-export test is skipped
without `npm run build`. Only `0 skipped` means everything ran. CI runs lint, typecheck, build and
the full suite in strict mode on every push and PR to `main`, where anything missing fails. Details:
[docs/DEVELOPMENT.md](docs/DEVELOPMENT.md#local-setup).

## Quick start

Generate an invoice (Node.js):

```ts
import { generateInvoice } from "openinvoicexml/adapters";

const { xml, issues } = generateInvoice(invoice); // invoice: see docs/DATA-MODEL.md

if (xml === null) {
  // issues contains at least one entry with severity: "error"
  for (const issue of issues) console.error(`${issue.code}: ${issue.message}`);
}
```

In the browser:

```ts
import { generateInvoiceXml } from "openinvoicexml/browser";

const { xml, issues } = generateInvoiceXml(invoice);
```

See [docs/API.md](docs/API.md) for every function and output format, and
[docs/EXAMPLES.md](docs/EXAMPLES.md) for three end-to-end walkthroughs (a standard invoice, a §19
small-business invoice and a hybrid PDF).

## Project structure

```
/core         — internal invoice schema and normalization
/adapters     — output adapters (XRechnung XML, CII, PDF/A-3)
/validators   — validation layer (schema, KoSIT, veraPDF, Mustang)
  /rules      — individual business rule implementations
/fixtures     — example invoices and expected outputs
/docs         — architecture, roadmap, and API docs
```

## Docs

German versions exist for [README](README.de.md), [supported scenarios](docs/SUPPORTED_SCENARIOS.de.md),
and an [API overview](docs/API.de.md). They are maintained by hand and may lag behind the English docs.

| Document                                                                                                      | Status |
| ------------------------------------------------------------------------------------------------------------- | ------ |
| `ARCHITECTURE.md` — Adapter pattern, module boundaries, data flow                                             | Done   |
| `DEVELOPMENT.md` — Local setup, available commands, TypeScript/dependency config, coding & commit conventions | Done   |
| `COMPLIANCE.md` — Index of compliance sources, rule → file → status map, KoSIT validation setup and usage     | Done   |
| `DATA-MODEL.md` — Internal invoice schema, full XRechnung BT mapping table                                    | Done   |
| `API.md` — API usage: `generateInvoiceDocument`, `generateInvoice`, `toXRechnung`, error codes                | Done   |
| `EXAMPLES.md` — Three end-to-end walkthroughs: standard invoice, §19 small business, hybrid PDF               | Done   |
| `FAQ.md` — Questions from freelancers and small businesses: legal dates, §19, formats, totals                 | Done   |
| `PERFORMANCE.md` — Measured generation and validation timings (`make benchmark`)                              | Done   |
| `ROADMAP.md` — Phase goals, non-goals, open questions                                                         | Done   |
| `SUPPORTED_SCENARIOS.md` — Supported, partially supported, and unsupported scenarios                          | Done   |
| `LIMITATIONS.md` — What is not supported and why                                                              | Done   |
| `SECURITY.md` — Security considerations and responsible disclosure                                            | Done   |
| `VERSIONING.md` — Public API, semantic versioning, breaking changes vs. bug fixes                             | Done   |

## Companion repo

The hosted website, beta/developer signup backend, and deploy tooling live in a separate repo,
[`openinvoicexml-web`](https://github.com/HongbaeKim/openinvoicexml-web), which consumes this
engine rather than the other way around.

## License

Apache-2.0

Optional external validators (KoSIT, Mustangproject, veraPDF) are independent projects under
their own licenses and are not bundled — see
[docs/COMPLIANCE.md](docs/COMPLIANCE.md#third-party-validation-tools).

---

<p>
  <img src="logo/en/BMFTR_en.png" alt="Logo of the German Federal Ministry of Research, Technology and Space" height="80">
  <img src="logo/en/P_en.png" alt="Prototype Fund logo" height="80">
</p>

[ustg-13b]: https://www.gesetze-im-internet.de/ustg_1980/__13b.html
[ustg-19]: https://www.gesetze-im-internet.de/ustg_1980/__19.html
